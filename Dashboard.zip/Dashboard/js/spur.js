/*!
 * spur-template - An admin template based on Bootstrap 4
 * Version v1.1.0
 * Copyright 2016 - 2019 Alexander Rechsteiner
 * https://hackerthemes.com
 */

const mobileBreakpoint = window.matchMedia("(max-width: 991px )");

$(document).ready(function(){
    $(".side-nav-dropdown-toggle").click(function(){
        $(this).closest(".side-nav-dropdown")
            .toggleClass("show")
            .find(".side-nav-dropdown")
            .removeClass("show");

        $(this).parent()
            .siblings()
            .removeClass("show");
    });

    $(".menu-toggle").click(function(){
        if (mobileBreakpoint.matches) {
            $(".side-nav").toggleClass("mobile-show");
        } else {
            $(".side").toggleClass("side-compact");
        }
    });

    $(".searchbox-toggle").click(function(){
        $(".searchbox").toggleClass("show");
    });

    // Dev utilities
    // $("header.side-toolbar .menu-toggle").click();
    // $(".searchbox-toggle").click();
});
